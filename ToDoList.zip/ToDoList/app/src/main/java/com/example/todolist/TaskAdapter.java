package com.example.todolist;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder> {

    private Context context;
    private ArrayList<TodoTask> taskList;
    private boolean aBoolean;

    public TaskAdapter(Context context, ArrayList<TodoTask> taskList) {
        this.context = context;
        this.taskList = taskList;
        aBoolean = false;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.task_rv, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TodoTask task = taskList.get(position);
        holder.titleTextView.setText(task.getTitle());
        holder.descriptionTextView.setText(task.getDescription());
        holder.imageView.setOnClickListener(view -> {
            if (aBoolean) {
                holder.cardView.setVisibility(View.GONE);
                aBoolean = false;
            } else {
                holder.cardView.setVisibility(View.VISIBLE);
                aBoolean = true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView descriptionTextView;
        ImageView imageView;
        CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.Title);
            descriptionTextView = itemView.findViewById(R.id.Description2);
            imageView = itemView.findViewById(R.id.drop);
            cardView = itemView.findViewById(R.id.dropdown);
        }
    }

    public interface OnItemSwipedListener {
        void onItemSwiped(int position);
    }

    private OnItemSwipedListener onItemSwipedListener;

    public void setOnItemSwipedListener(OnItemSwipedListener onItemSwipedListener) {
        this.onItemSwipedListener = onItemSwipedListener;
    }

    public void enableSwipe(RecyclerView recyclerView) {
        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            private final ColorDrawable background = new ColorDrawable(Color.RED);
            private Drawable deleteIcon = ContextCompat.getDrawable(context, R.drawable.bin);
            private Drawable updateIcon = ContextCompat.getDrawable(context, R.drawable.edit);
            private final int intrinsicWidth = deleteIcon.getIntrinsicWidth();
            private final int intrinsicHeight = deleteIcon.getIntrinsicHeight();

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                if (onItemSwipedListener != null) {
                    onItemSwipedListener.onItemSwiped(viewHolder.getAdapterPosition());
                }
            }


            // Replace the onChildDraw method with the following code

            // Replace the onChildDraw method with the following code
            @Override
            public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);

                View itemView = viewHolder.itemView;
                int itemHeight = itemView.getBottom() - itemView.getTop();
                boolean isCancelled = dX == 0f && !isCurrentlyActive;

                if (isCancelled) {
                    clearCanvas(c, itemView.getRight() + dX, (float) itemView.getTop(), (float) itemView.getRight(), (float) itemView.getBottom());
                    super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
                    return;
                }

                // Draw the red delete background
                Paint paint = new Paint();
                paint.setColor(ContextCompat.getColor(context, R.color.orange)); // Use the desired color here
                c.drawRect(itemView.getRight() + dX, (float) itemView.getTop(), (float) itemView.getRight(), (float) itemView.getBottom(), paint);

                // ... (rest of the code remains the same)
            }

            @SuppressLint("ResourceAsColor")
            private void clearCanvas(@NonNull Canvas c, Float left, Float top, Float right, Float bottom) {
                Paint paint = new Paint();
                paint.setColor(ContextCompat.getColor(context, R.color.orange)); // Use the desired color here
                c.drawRect(left, top, right, bottom, paint);
            }

        };
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }
}
