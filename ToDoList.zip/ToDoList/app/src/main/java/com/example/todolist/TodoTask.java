package com.example.todolist;

import android.content.SharedPreferences;

public class TodoTask {
    private String title;
    private String description;

    public TodoTask(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    // Serialize TodoTask data to a SharedPreferences instance
    public void saveToSharedPreferences(SharedPreferences preferences, String key) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key + "_title", title);
        editor.putString(key + "_description", description);
        editor.apply();
    }

    // Deserialize TodoTask data from a SharedPreferences instance
    public static TodoTask loadFromSharedPreferences(SharedPreferences preferences, String key) {
        String title = preferences.getString(key + "_title", "");
        String description = preferences.getString(key + "_description", "");
        return new TodoTask(title, description);
    }
}
