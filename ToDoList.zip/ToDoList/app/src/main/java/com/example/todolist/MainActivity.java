package com.example.todolist;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private TaskAdapter taskAdapter;
    private ArrayList<TodoTask> taskList;
    private RecyclerView recyclerView;
    private SharedPreferences preferences;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preferences = getSharedPreferences("task_data", Context.MODE_PRIVATE);
        taskList = new ArrayList<>();
        loadTasksFromSharedPreferences();

        recyclerView = findViewById(R.id.recyclerView);
        taskAdapter = new TaskAdapter(this, taskList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(taskAdapter);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                if (direction == ItemTouchHelper.RIGHT) {
                    taskList.remove(position);
                    saveTasksToSharedPreferences();
                    updateTaskAdapter();
                    Toast.makeText(MainActivity.this, "Task Removed", Toast.LENGTH_SHORT).show();
                } else if (direction == ItemTouchHelper.LEFT) {
                    // Handle update task
                    showUpdateDialog(taskList.get(position), position);
                }
            }
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);

        ImageButton button = findViewById(R.id.Add);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBottomDialog();
            }
        });
    }

    private void showUpdateDialog(TodoTask task, int position) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.bottom_sheet);

        Button button = dialog.findViewById(R.id.add_task);
        EditText titleEditText = dialog.findViewById(R.id.Title);
        TextView textView = dialog.findViewById(R.id.textView);
        EditText descriptionEditText = dialog.findViewById(R.id.Description2);

        button.setText("Update");
        textView.setText("Update Task");

        titleEditText.setText(task.getTitle());
        descriptionEditText.setText(task.getDescription());

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = titleEditText.getText().toString();
                String description = descriptionEditText.getText().toString();

                if (title.isEmpty() || description.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both title and description", Toast.LENGTH_SHORT).show();
                } else {
                    taskList.set(position, new TodoTask(title, description));
                    saveTasksToSharedPreferences();
                    updateTaskAdapter();
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "Task Updated", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ImageView cancelButton = dialog.findViewById(R.id.cancel);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
        }
    }

    private void showBottomDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.bottom_sheet);

        Button button = dialog.findViewById(R.id.add_task);
        EditText titleEditText = dialog.findViewById(R.id.Title);
        EditText descriptionEditText = dialog.findViewById(R.id.Description2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = titleEditText.getText().toString();
                String description = descriptionEditText.getText().toString();

                if (title.isEmpty() || description.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both title and description", Toast.LENGTH_SHORT).show();
                } else {
                    taskList.add(new TodoTask(title, description));
                    saveTasksToSharedPreferences();
                    updateTaskAdapter();
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "Task Added", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ImageView cancelButton = dialog.findViewById(R.id.cancel);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
        }
    }

    private void updateTaskAdapter() {
        taskAdapter.notifyDataSetChanged();
    }

    private void saveTasksToSharedPreferences() {
        Set<String> taskSet = new HashSet<>();
        for (TodoTask task : taskList) {
            taskSet.add(task.getTitle() + "|" + task.getDescription());
        }

        SharedPreferences.Editor editor = preferences.edit();
        editor.putStringSet("tasks", taskSet);
        editor.apply();
    }

    private void loadTasksFromSharedPreferences() {
        Set<String> taskSet = preferences.getStringSet("tasks", new HashSet<>());
        taskList.clear();
        for (String taskString : taskSet) {
            String[] taskInfo = taskString.split("\\|");
            if (taskInfo.length == 2) {
                String title = taskInfo[0];
                String description = taskInfo[1];
                taskList.add(new TodoTask(title, description));
            }
        }
    }
}
